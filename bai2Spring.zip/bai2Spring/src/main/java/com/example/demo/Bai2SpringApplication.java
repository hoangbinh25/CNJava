package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bai2SpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(Bai2SpringApplication.class, args);
	}

}
